﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp11
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        string Haslo = ""; 
        string Haslo2 = "";
        string liczby = "1234567890";
        string maleLitery = "qazwsxedcrfvtgbyhnujmikolp";
        string duzeLitery = "QAZWSXEDCRFVTGBYHNUJMIKOLP";
        string znakiSpecjalne = "!@#$%^&*()_+-=";
        string nazwiskoPo = "";
        string imiePo = "";
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Random randomo =  new Random();
            int liczbCheekow = 0;
            bool wylosowanoDuza = true;
            bool wylosowanoCyfre = true;
            bool wylosowanoZnakSpecjalny = true;
            bool duzeLiterki = false;
            bool cyferki = false;
            bool znaki = false;
            int randomowa = randomo.Next(maleLitery.Length);
            if (int.TryParse(iloscLiczb.Text, out int result))
            {
                if(maleIDuze.IsChecked == true)
                {
                    duzeLiterki = true;
                    liczbCheekow++;
                }
                if (cyfry.IsChecked == true)
                {
                    cyferki = true;
                    liczbCheekow++;
                }
                if (znaczkiSpecjalne.IsChecked == true)
                {
                    znaki = true;
                    liczbCheekow++;
                }

                for (int i = 0; i < result; i++)
                {
                    randomowa = randomo.Next(4);
                    if ((i == 2 || i == 1 || i == 0)&&(cyferki && wylosowanoCyfre))
                    {
                        randomowa = randomo.Next(liczby.Length);
                        Haslo += liczby[randomowa];
                        wylosowanoCyfre = false;
                    }
                    else if ((i == 2 || i == 1 || i == 0) && ( duzeLiterki && wylosowanoDuza))
                    {
                        randomowa = randomo.Next(duzeLitery.Length);
                        Haslo += duzeLitery[randomowa];
                        wylosowanoDuza = false;
                    }
                    else if ((i == 2 ||i == 1|| i ==0) && (znaki && wylosowanoZnakSpecjalny))
                    {
                        randomowa = randomo.Next(znakiSpecjalne.Length);
                        Haslo += znakiSpecjalne[randomowa];
                        wylosowanoZnakSpecjalny = false;
                    }
                    else
                    {
                        randomowa = randomo.Next(maleLitery.Length);
                        Haslo += maleLitery[randomowa];
                    }
                }
                MessageBox.Show(Haslo);
                Haslo2 = Haslo;
                Haslo = "";
            }
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            if(string.IsNullOrEmpty(nazwisko.Text) || string.IsNullOrEmpty(imie.Text))
            {
                MessageBox.Show("Podaj imie i nazwisko");
            }
            else
            {

                bool jest = true;
                for(int i = 0; i < nazwisko.Text.Length; i++)
                {
                    for(int j = 0; j < liczby.Length; j++)
                    {
                        if (nazwisko.Text[i] == liczby[j])
                        {
                            jest = false;
                        }
                    }
                    if (jest)
                    {
                        if (i == 0)
                        {
                            string nazwiskoDuze = nazwisko.Text.ToUpper();
                            nazwiskoPo += nazwiskoDuze[i];
                        }
                        else
                        {
                            nazwiskoPo += nazwisko.Text[i];
                        }
                    }
                    jest = true;
                }
                for (int i = 0; i < imie.Text.Length; i++)
                {
                    for (int j = 0; j < liczby.Length; j++)
                    {
                        if (imie.Text[i] == liczby[j])
                        {
                            jest = false;
                        }
                    }
                    if (jest)
                    {
                        if (i == 0)
                        {
                            string imieDuze = imie.Text.ToUpper();
                            imiePo += imieDuze[i];
                        }
                        else
                        {
                            imiePo += imie.Text[i];
                        }
                    }
                    jest = true;
                }
            }
            MessageBox.Show("Imie: " + imiePo + " Nazwisko: " + nazwiskoPo+ comboBoxZRzeczami.Text + " Hasło: " + Haslo2);
            
        }
    }
}
